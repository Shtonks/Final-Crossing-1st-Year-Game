-- tiled Plugin template

-- Use this as a template to extend a tiled object with functionality
local M = {}

function M.new(instance)

  if not instance then error("ERROR: Expected display object") end
-- 
-- local scene = composer.getScene( composer.getSceneName( "current" ) )

  function instance:collision( event )
        if( event.phase == "began" ) then

          local obj1 = event.object1
          local obj2 = event.object2

            if( obj1.myName == "character" and obj2.myName == "heart" )  then

                      livesCount = livesCount + 1
                      livesText.text = "x" .. livesCount
                      event.object2:removeSelf()
                      event.object2 = nil
            end
            if ( obj1.myName == "heart" and obj2.myName == "character" )  then

                       livesCount = livesCount + 1
                       livesText.text = "x" .. livesCount
                       event.object1:removeSelf()
                       event.object1 = nil
            end
        end
  end

instance:addEventListener( "collision")
  return instance
end

return M
