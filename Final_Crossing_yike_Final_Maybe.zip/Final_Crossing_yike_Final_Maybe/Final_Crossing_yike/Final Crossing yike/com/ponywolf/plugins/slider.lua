-- slider, really just an empty template

local M = {}

function M.new(instance)

  if not instance then error("ERROR: Expected display object") end
    
  return instance
end

return M