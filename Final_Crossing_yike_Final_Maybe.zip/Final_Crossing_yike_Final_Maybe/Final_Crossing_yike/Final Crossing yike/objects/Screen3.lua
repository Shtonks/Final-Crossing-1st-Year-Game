return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 12,
  nextobjectid = 449,
  properties = {
    ["bodyType"] = "static"
  },
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 1033,
      tileheight = 658,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 76,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        },
        {
          id = 139,
          image = "asjadj.png",
          width = 128,
          height = 128
        },
        {
          id = 140,
          image = "asjadj_smaller.png",
          width = 96,
          height = 128
        },
        {
          id = 141,
          image = "Background2.png",
          width = 1033,
          height = 581
        },
        {
          id = 142,
          image = "CLIFF1.png",
          width = 96,
          height = 128
        },
        {
          id = 143,
          image = "CLIFF2.png",
          width = 128,
          height = 128
        },
        {
          id = 144,
          image = "dirt2.png",
          width = 32,
          height = 32
        },
        {
          id = 145,
          image = "floorPalace.png",
          width = 32,
          height = 32
        },
        {
          id = 146,
          image = "green.png",
          width = 32,
          height = 32
        },
        {
          id = 147,
          image = "green_top.png",
          width = 32,
          height = 32
        },
        {
          id = 148,
          image = "green2.png",
          width = 32,
          height = 32
        },
        {
          id = 149,
          image = "l_o_n_g.png",
          width = 59,
          height = 658
        },
        {
          id = 150,
          image = "oop.png",
          width = 352,
          height = 256
        },
        {
          id = 151,
          image = "oop2.png",
          width = 352,
          height = 256
        },
        {
          id = 152,
          image = "wallPALACE.png",
          width = 32,
          height = 32
        },
        {
          id = 153,
          image = "Window.png",
          width = 192,
          height = 416
        },
        {
          id = 154,
          image = "exitSurface.png",
          width = 64,
          height = 32
        },
        {
          id = 155,
          image = "platform3SMALL.png",
          width = 96,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 8,
      name = "sensors",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 365,
          name = "sensor1",
          type = "",
          shape = "rectangle",
          x = 960,
          y = 448,
          width = 640,
          height = 32,
          rotation = 0,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 444,
          name = "sensor2",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 672,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 3,
      name = "turrets",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 73,
          name = "turret6",
          type = "turret",
          shape = "rectangle",
          x = 224,
          y = 32,
          width = 40,
          height = 60,
          rotation = 90,
          gid = 1073741920,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 74,
          name = "turret10",
          type = "turret",
          shape = "rectangle",
          x = 1397.67,
          y = 687.667,
          width = 40,
          height = 60,
          rotation = 90,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 75,
          name = "turret7",
          type = "turret",
          shape = "rectangle",
          x = 160,
          y = 672,
          width = 40,
          height = 60,
          rotation = 270,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 82,
          name = "turret9",
          type = "turret",
          shape = "rectangle",
          x = 960,
          y = 800,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 78,
          name = "turret4",
          type = "turret",
          shape = "rectangle",
          x = 927.667,
          y = 552,
          width = 40,
          height = 60,
          rotation = -180,
          gid = 1073741920,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 80,
          name = "turret2",
          type = "turret",
          shape = "rectangle",
          x = 702.125,
          y = 1024,
          width = 40,
          height = 60,
          rotation = 270,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 81,
          name = "turret1",
          type = "turret",
          shape = "rectangle",
          x = 315.977,
          y = 1056.19,
          width = 40,
          height = 60,
          rotation = -90,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 77,
          name = "turret3",
          type = "turret",
          shape = "rectangle",
          x = 465.53,
          y = 607.826,
          width = 40,
          height = 60,
          rotation = 90,
          gid = 1073741920,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 86,
          name = "turret11",
          type = "turret",
          shape = "rectangle",
          x = 1888,
          y = 128,
          width = 40,
          height = 60,
          rotation = -180,
          gid = 1073741920,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 87,
          name = "turret12",
          type = "turret",
          shape = "rectangle",
          x = 1888,
          y = 224,
          width = 40,
          height = 60,
          rotation = 180,
          gid = 1073741920,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 88,
          name = "turret13",
          type = "turret",
          shape = "rectangle",
          x = 1888,
          y = 320,
          width = 40,
          height = 60,
          rotation = -180,
          gid = 1073741920,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 85,
          name = "turret14",
          type = "turret",
          shape = "rectangle",
          x = 960,
          y = 574.75,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 6,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 95,
          name = "spikes4",
          type = "spikes",
          shape = "rectangle",
          x = 1600,
          y = 992,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 65,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 96,
          name = "spikes6",
          type = "spikes",
          shape = "rectangle",
          x = 928,
          y = 256,
          width = 32,
          height = 32,
          rotation = 270,
          gid = 65,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 320,
          name = "spikes1",
          type = "spikes",
          shape = "rectangle",
          x = 320,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 321,
          name = "spikes2",
          type = "spikes",
          shape = "rectangle",
          x = 1632,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 322,
          name = "spikes3",
          type = "spikes",
          shape = "rectangle",
          x = 704,
          y = 1024,
          width = 128,
          height = 26,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 323,
          name = "spikes5",
          type = "spikes",
          shape = "rectangle",
          x = 928,
          y = 768,
          width = 128,
          height = 32,
          rotation = -90,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 429,
          name = "timedSpikes1",
          type = "",
          shape = "rectangle",
          x = 1487.82,
          y = 992,
          width = 112,
          height = 32,
          rotation = 0,
          gid = 137,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 430,
          name = "spikes9",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 384,
          width = 128,
          height = 32,
          rotation = 180,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 431,
          name = "spikes8",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 384,
          width = 128,
          height = 32,
          rotation = 180,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 432,
          name = "spikes7",
          type = "",
          shape = "rectangle",
          x = 1600,
          y = 384,
          width = 128,
          height = 32,
          rotation = 180,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 433,
          name = "spikesSens",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 384,
          width = 128,
          height = 32,
          rotation = 180,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 443,
          name = "sensorSpikes5",
          type = "",
          shape = "rectangle",
          x = 1920,
          y = 800,
          width = 128,
          height = 32,
          rotation = 270,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 11,
      name = "brickwork",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 211,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 212,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 213,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 214,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 215,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 219,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 220,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 221,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 416,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 222,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 800,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 223,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1056,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 224,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 416,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 225,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 1056,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 230,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1696,
          y = 544,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 236,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632.02,
          y = 688.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 237,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1696.02,
          y = 688.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 238,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760.02,
          y = 688.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 239,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824.02,
          y = 688.087,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 240,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1312.02,
          y = 688.002,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 241,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184.02,
          y = 688.002,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 243,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184.02,
          y = 656.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 244,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248.02,
          y = 656.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 245,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1312.02,
          y = 656.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 246,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376.02,
          y = 656.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 247,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1440.02,
          y = 656.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 281,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 608,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 286,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 1056,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 287,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 1024,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 288,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 289,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 960,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 292,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 1088,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 293,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 1088,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 294,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 960,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 295,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 704,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 296,
          name = "",
          type = "",
          shape = "rectangle",
          x = 31.9583,
          y = 592.167,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 297,
          name = "",
          type = "",
          shape = "rectangle",
          x = 95.9583,
          y = 592.167,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 298,
          name = "",
          type = "",
          shape = "rectangle",
          x = 160.001,
          y = 591.993,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 304,
          name = "",
          type = "",
          shape = "rectangle",
          x = 31.75,
          y = 336,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 305,
          name = "",
          type = "",
          shape = "rectangle",
          x = 95.75,
          y = 336,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 306,
          name = "",
          type = "",
          shape = "rectangle",
          x = 159.75,
          y = 336,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 307,
          name = "",
          type = "",
          shape = "rectangle",
          x = 223.75,
          y = 336,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 308,
          name = "",
          type = "",
          shape = "rectangle",
          x = 114.5,
          y = 464.583,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 309,
          name = "",
          type = "",
          shape = "rectangle",
          x = 178.5,
          y = 464.583,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 310,
          name = "",
          type = "",
          shape = "rectangle",
          x = 242.5,
          y = 464.583,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 311,
          name = "",
          type = "",
          shape = "rectangle",
          x = 306.5,
          y = 464.583,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 312,
          name = "",
          type = "",
          shape = "rectangle",
          x = 114.25,
          y = 208.333,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 313,
          name = "",
          type = "",
          shape = "rectangle",
          x = 178.25,
          y = 208.333,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 314,
          name = "",
          type = "",
          shape = "rectangle",
          x = 242.25,
          y = 208.333,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 315,
          name = "",
          type = "",
          shape = "rectangle",
          x = 306.25,
          y = 208.333,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 316,
          name = "",
          type = "",
          shape = "rectangle",
          x = 370.25,
          y = 224.342,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 317,
          name = "",
          type = "",
          shape = "rectangle",
          x = 370.26,
          y = 608.32,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 318,
          name = "",
          type = "",
          shape = "rectangle",
          x = 370.25,
          y = 672.114,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 329,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 330,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 331,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 338,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224,
          y = 1088,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 344,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 345,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 347,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1504,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 348,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 349,
          name = "",
          type = "",
          shape = "rectangle",
          x = 736,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 350,
          name = "",
          type = "",
          shape = "rectangle",
          x = 640,
          y = 1056,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 351,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 358,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 672,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 366,
          name = "",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 367,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224.051,
          y = 592.004,
          width = 32,
          height = 16,
          rotation = 0,
          gid = 114,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 368,
          name = "",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 369,
          name = "",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 370,
          name = "",
          type = "",
          shape = "rectangle",
          x = 468.5,
          y = 370.5,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 371,
          name = "",
          type = "",
          shape = "rectangle",
          x = 465.545,
          y = 607.977,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 373,
          name = "",
          type = "",
          shape = "rectangle",
          x = 352,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 374,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 375,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 376,
          name = "",
          type = "",
          shape = "rectangle",
          x = 512,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 377,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 378,
          name = "",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 379,
          name = "",
          type = "",
          shape = "rectangle",
          x = 736,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 380,
          name = "",
          type = "",
          shape = "rectangle",
          x = 704,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 381,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 382,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 383,
          name = "",
          type = "",
          shape = "rectangle",
          x = 736,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 384,
          name = "",
          type = "",
          shape = "rectangle",
          x = 736,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 385,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 386,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 387,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 388,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 389,
          name = "",
          type = "",
          shape = "rectangle",
          x = 736,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 390,
          name = "",
          type = "",
          shape = "rectangle",
          x = 960,
          y = 416,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 391,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 416,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 392,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 416,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 393,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 192,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 395,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 397,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1312,
          y = 224,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 398,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 399,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 400,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 401,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1440.25,
          y = 586.75,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 402,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184.5,
          y = 588.5,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 403,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1504.02,
          y = 656.002,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 410,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 864,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 411,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 864,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 418,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 1024,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 419,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1504,
          y = 1024,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 437,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1695.91,
          y = 557.818,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 438,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1567.98,
          y = 656.05,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 439,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1567.99,
          y = 687.976,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 440,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1600.02,
          y = 687.94,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 446,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 356,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 704,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 404,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 832,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 424,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 896,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 425,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 896,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 445,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 412,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 864,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 413,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 896,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 414,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 415,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 960,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 416,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 420,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 960,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 421,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 423,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 434,
          name = "",
          type = "",
          shape = "rectangle",
          x = 960,
          y = 448,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "interactable",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 97,
          name = "heart",
          type = "collectables",
          shape = "rectangle",
          x = 307.083,
          y = 576.583,
          width = 43.6667,
          height = 43.6667,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 98,
          name = "feather",
          type = "collectables",
          shape = "rectangle",
          x = 1792,
          y = 800,
          width = 54,
          height = 72,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 426,
          name = "wall1",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 864,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 427,
          name = "button",
          type = "",
          shape = "rectangle",
          x = 992.333,
          y = 944.333,
          width = 16,
          height = 16,
          rotation = 0,
          gid = 131,
          visible = true,
          properties = {}
        },
        {
          id = 441,
          name = "flagYes",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 160,
          width = 48.125,
          height = 96.25,
          rotation = 0,
          gid = 98,
          visible = true,
          properties = {}
        },
        {
          id = 442,
          name = "flagNo",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 160,
          width = 48,
          height = 96,
          rotation = 0,
          gid = 97,
          visible = true,
          properties = {}
        },
        {
          id = 99,
          name = "exit",
          type = "exits",
          shape = "rectangle",
          x = 40.5,
          y = 928.5,
          width = 87.4146,
          height = 123.167,
          rotation = 0,
          gid = 85,
          visible = true,
          properties = {}
        },
        {
          id = 156,
          name = "",
          type = "",
          shape = "rectangle",
          x = 207.5,
          y = 747.5,
          width = 53.5,
          height = 53.5,
          rotation = 0,
          gid = 86,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
