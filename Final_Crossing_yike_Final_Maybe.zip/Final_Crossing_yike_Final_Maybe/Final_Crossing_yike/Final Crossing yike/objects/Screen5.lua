return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 15,
  nextobjectid = 1860,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 1033,
      tileheight = 658,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 76,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        },
        {
          id = 139,
          image = "asjadj.png",
          width = 128,
          height = 128
        },
        {
          id = 140,
          image = "asjadj_smaller.png",
          width = 96,
          height = 128
        },
        {
          id = 141,
          image = "Background2.png",
          width = 1033,
          height = 581
        },
        {
          id = 142,
          image = "CLIFF1.png",
          width = 96,
          height = 128
        },
        {
          id = 143,
          image = "CLIFF2.png",
          width = 128,
          height = 128
        },
        {
          id = 144,
          image = "dirt2.png",
          width = 32,
          height = 32
        },
        {
          id = 145,
          image = "floorPalace.png",
          width = 32,
          height = 32
        },
        {
          id = 146,
          image = "green.png",
          width = 32,
          height = 32
        },
        {
          id = 147,
          image = "green_top.png",
          width = 32,
          height = 32
        },
        {
          id = 148,
          image = "green2.png",
          width = 32,
          height = 32
        },
        {
          id = 149,
          image = "l_o_n_g.png",
          width = 59,
          height = 658
        },
        {
          id = 150,
          image = "oop.png",
          width = 352,
          height = 256
        },
        {
          id = 151,
          image = "oop2.png",
          width = 352,
          height = 256
        },
        {
          id = 152,
          image = "wallPALACE.png",
          width = 32,
          height = 32
        },
        {
          id = 153,
          image = "Window.png",
          width = 192,
          height = 416
        },
        {
          id = 154,
          image = "exitSurface.png",
          width = 64,
          height = 32
        },
        {
          id = 155,
          image = "platform3SMALL.png",
          width = 96,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 14,
      name = "sensors",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1855,
          name = "sensor1",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 672,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 5,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1698,
          name = "staticSpikes4",
          type = "",
          shape = "rectangle",
          x = 1056,
          y = 288,
          width = 384,
          height = 26,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1699,
          name = "staticSpikes3",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 1056,
          width = 384,
          height = 28.375,
          rotation = -90,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1700,
          name = "staticSpikes2",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 672,
          width = 384,
          height = 28,
          rotation = 270,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1701,
          name = "staticSpikes1",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 608,
          width = 384,
          height = 28,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1684,
          name = "timedSpikes1",
          type = "",
          shape = "rectangle",
          x = 352,
          y = 608,
          width = 32,
          height = 32,
          rotation = -180,
          gid = 69,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1765,
          name = "staticSpikes7",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1772,
          name = "staticSpikes5",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 288,
          width = 384,
          height = 26,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1792,
          name = "sensorSpikes",
          type = "",
          shape = "rectangle",
          x = 1122.25,
          y = 672,
          width = 128,
          height = 29.75,
          rotation = 90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1794,
          name = "timedSpikes2",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1819,
          name = "staticSpikes6",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1856,
          name = "wall2",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 640,
          width = 160,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1857,
          name = "wall3",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 640,
          width = 160,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 12,
      name = "decals",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 275,
          name = "",
          type = "",
          shape = "text",
          x = 53.71,
          y = -64,
          width = 407.333,
          height = 62.6667,
          rotation = 0,
          visible = true,
          text = "Screen5",
          pixelsize = 50,
          wrap = true,
          properties = {}
        },
        {
          id = 1795,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1696,
          y = 32,
          width = 992,
          height = 32,
          rotation = 90,
          gid = 1073741901,
          visible = true,
          properties = {}
        },
        {
          id = 1796,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 32.5,
          width = 992,
          height = 32.625,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1797,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1728,
          y = 1024,
          width = 128,
          height = 992,
          rotation = 0,
          gid = 112,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 10,
      name = "brickwork",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1650,
          name = "",
          type = "",
          shape = "rectangle",
          x = -64,
          y = 192,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1651,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1652,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 800,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1653,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224,
          y = 800,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1657,
          name = "",
          type = "",
          shape = "rectangle",
          x = 736,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1658,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1659,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1660,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1661,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 640,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1686,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1024,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1687,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1688,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1440,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1689,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1280,
          y = 1056,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1726,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 1056,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1727,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 672,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1710,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1711,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1712,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1713,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1714,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1715,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1716,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1717,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1718,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1719,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1720,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1056,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1721,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 672,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1722,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 320,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1723,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 1056,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1724,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 672,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1725,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 288,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1728,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 640,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1729,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 640,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1730,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1734,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 864,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1735,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 640,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1736,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184,
          y = 640,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1737,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 896,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1738,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 1088,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1740,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 832,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1741,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 832,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1742,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1743,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 896,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1744,
          name = "",
          type = "",
          shape = "rectangle",
          x = 960,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1745,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1746,
          name = "",
          type = "",
          shape = "rectangle",
          x = 160,
          y = 576,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1747,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 576,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1748,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 576,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1749,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 576,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1750,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 576,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1751,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1752,
          name = "",
          type = "",
          shape = "rectangle",
          x = 160,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1753,
          name = "",
          type = "",
          shape = "rectangle",
          x = 640,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1754,
          name = "",
          type = "",
          shape = "rectangle",
          x = 608,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1755,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1756,
          name = "",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1757,
          name = "",
          type = "",
          shape = "rectangle",
          x = 512,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1758,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1759,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 352,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1732,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1024,
          y = 320,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1733,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 320,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1779,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1817,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1818,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 512,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1825,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1024,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1800,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376,
          y = 944.292,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1801,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 944.292,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1802,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1803,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1805,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1858,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 8,
      name = "rails",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1642,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1658.23,
          y = 811.647,
          width = 32,
          height = 9.18881,
          rotation = 308.876,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1643,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1678.34,
          y = 786.755,
          width = 158.505,
          height = 9.25294,
          rotation = 308.876,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1644,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1790.23,
          y = 633.152,
          width = 32,
          height = 9.38899,
          rotation = 488.876,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1645,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 807,
          width = 206,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1646,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448.008,
          y = 776.937,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1647,
          name = "",
          type = "",
          shape = "rectangle",
          x = 463.987,
          y = 1044.75,
          width = 32,
          height = 16,
          rotation = 270,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1678,
          name = "",
          type = "",
          shape = "rectangle",
          x = 312.508,
          y = 171.188,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1679,
          name = "",
          type = "",
          shape = "rectangle",
          x = 312.5,
          y = 202.563,
          width = 297.063,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1680,
          name = "",
          type = "",
          shape = "rectangle",
          x = 328.487,
          y = 531.313,
          width = 32,
          height = 16,
          rotation = 270,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1681,
          name = "",
          type = "",
          shape = "rectangle",
          x = 872,
          y = 717.636,
          width = 306.364,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1683,
          name = "",
          type = "",
          shape = "rectangle",
          x = 871.974,
          y = 686.38,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1760,
          name = "",
          type = "",
          shape = "rectangle",
          x = 856.542,
          y = 333.531,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1761,
          name = "",
          type = "",
          shape = "rectangle",
          x = 856.526,
          y = 365.173,
          width = 166.447,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1762,
          name = "",
          type = "",
          shape = "rectangle",
          x = 872.514,
          y = 563.37,
          width = 32,
          height = 16,
          rotation = 270,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1785,
          name = "",
          type = "",
          shape = "rectangle",
          x = 137.67,
          y = 780.105,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1786,
          name = "",
          type = "",
          shape = "rectangle",
          x = 137.667,
          y = 812.022,
          width = 139.708,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1787,
          name = "",
          type = "",
          shape = "rectangle",
          x = 153.654,
          y = 983.48,
          width = 32,
          height = 16,
          rotation = 270,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1807,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1166.98,
          y = 215.51,
          width = 32,
          height = 16,
          rotation = 0,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1808,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1519,
          y = 199.5,
          width = 321.492,
          height = 16,
          rotation = -180,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1809,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1551,
          y = 199.5,
          width = 32,
          height = 16,
          rotation = -180,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1846,
          name = "exit",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1850,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1410.49,
          y = 433.715,
          width = 32,
          height = 16,
          rotation = 22.7995,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1851,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1750.95,
          y = 559.476,
          width = 32,
          height = 16,
          rotation = -157.201,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1852,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1721.45,
          y = 547.076,
          width = 299.685,
          height = 16,
          rotation = -157.201,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1859,
          name = "wall1",
          type = "",
          shape = "rectangle",
          x = 672,
          y = 640,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 9,
      name = "movingPlatforms",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1539,
          name = "mov1",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 544,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 79,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1554,
          name = "mov2",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 352,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 79,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1560,
          name = "mov5",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 224,
          width = 160,
          height = 32,
          rotation = 0,
          gid = 79,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1574,
          name = "mov3",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 704,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1582,
          name = "mov4",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 992,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1609,
          name = "mov6",
          type = "",
          shape = "rectangle",
          x = 1696,
          y = 576,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 7,
      name = "blades",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1580,
          name = "saw2",
          type = "blades",
          shape = "rectangle",
          x = 672,
          y = 896,
          width = 108.667,
          height = 108.667,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 51
          }
        },
        {
          id = 1550,
          name = "saw1",
          type = "blades",
          shape = "rectangle",
          x = 192,
          y = 480,
          width = 94,
          height = 94,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 46
          }
        },
        {
          id = 1551,
          name = "saw0",
          type = "blades",
          shape = "rectangle",
          x = 352,
          y = 256,
          width = 96,
          height = 96,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 46
          }
        },
        {
          id = 1586,
          name = "saw3",
          type = "blades",
          shape = "rectangle",
          x = 402.727,
          y = 1088.36,
          width = 108.667,
          height = 108.667,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 52
          }
        },
        {
          id = 1588,
          name = "saw4",
          type = "blades",
          shape = "rectangle",
          x = 0,
          y = 736,
          width = 108.667,
          height = 108.667,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 52
          }
        },
        {
          id = 1612,
          name = "saw5",
          type = "blades",
          shape = "rectangle",
          x = 1536.67,
          y = 608,
          width = 87.167,
          height = 87.167,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 42
          }
        },
        {
          id = 1619,
          name = "saw7",
          type = "blades",
          shape = "rectangle",
          x = 1632,
          y = 832,
          width = 58,
          height = 58,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 27
          }
        },
        {
          id = 1820,
          name = "staticSpikes8",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 864,
          width = 32,
          height = 32,
          rotation = 90,
          gid = 65,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1853,
          name = "saw6",
          type = "blades",
          shape = "rectangle",
          x = 1350.67,
          y = 605,
          width = 87.167,
          height = 87.167,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 42
          }
        },
        {
          id = 1854,
          name = "trigger",
          type = "",
          shape = "rectangle",
          x = 1216.19,
          y = 752.125,
          width = 16,
          height = 16,
          rotation = 0,
          gid = 131,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 11,
      name = "bullets",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1675,
          name = "bullet1",
          type = "",
          shape = "rectangle",
          x = 61.75,
          y = 878.875,
          width = 24.6667,
          height = 7.66667,
          rotation = 180,
          gid = 76,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1677,
          name = "bullet2",
          type = "",
          shape = "rectangle",
          x = 61.1818,
          y = 970.455,
          width = 24.6667,
          height = 7.66667,
          rotation = 180,
          gid = 76,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1691,
          name = "bullet3",
          type = "",
          shape = "rectangle",
          x = 700.42,
          y = 140.869,
          width = 24.6667,
          height = 7.66667,
          rotation = 180,
          gid = 76,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1764,
          name = "bullet3half",
          type = "",
          shape = "rectangle",
          x = 700.42,
          y = 140.869,
          width = 24.6667,
          height = 7.66667,
          rotation = 180,
          gid = 76,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1780,
          name = "bullet5",
          type = "",
          shape = "rectangle",
          x = 1372.34,
          y = 996.625,
          width = 24.6667,
          height = 7.66667,
          rotation = 450,
          gid = 76,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1781,
          name = "bullet4",
          type = "",
          shape = "rectangle",
          x = 1053.08,
          y = 444.364,
          width = 24.6667,
          height = 7.66667,
          rotation = 180,
          gid = 76,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 6,
      name = "turrets",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1672,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32.4848,
          y = 912.727,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {}
        },
        {
          id = 1673,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32.1212,
          y = 1004.24,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {}
        },
        {
          id = 1690,
          name = "turret3",
          type = "",
          shape = "rectangle",
          x = 672.125,
          y = 174.313,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {}
        },
        {
          id = 1731,
          name = "",
          type = "",
          shape = "rectangle",
          x = 326.727,
          y = 666.727,
          width = 19.4545,
          height = 19.4545,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 1782,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1405.69,
          y = 1024.16,
          width = 40,
          height = 60,
          rotation = 270,
          gid = 96,
          visible = true,
          properties = {}
        },
        {
          id = 1783,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1023.82,
          y = 478.216,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {}
        },
        {
          id = 1810,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1126.79,
          y = 1049.7,
          width = 19.4545,
          height = 19.4545,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 1811,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1156.97,
          y = 1050.06,
          width = 19.4545,
          height = 19.4545,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 1812,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1190.79,
          y = 1049.88,
          width = 19.4545,
          height = 19.4545,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 1813,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1223.7,
          y = 1049.7,
          width = 19.4545,
          height = 19.4545,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 1815,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1125,
          y = 776.75,
          width = 22,
          height = 22,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 1816,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1125.75,
          y = 715.5,
          width = 22,
          height = 22,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 13,
      name = "interactable",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1596,
          name = "exitSurface",
          type = "",
          shape = "rectangle",
          x = 1744,
          y = 1024,
          width = 96.6667,
          height = 145,
          rotation = 0,
          gid = 85,
          visible = true,
          properties = {}
        },
        {
          id = 1692,
          name = "flagYes",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 256,
          width = 47.3333,
          height = 94.6667,
          rotation = 0,
          gid = 98,
          visible = true,
          properties = {}
        },
        {
          id = 1693,
          name = "flagNo",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 256,
          width = 48.1667,
          height = 96.3333,
          rotation = 0,
          gid = 97,
          visible = true,
          properties = {}
        },
        {
          id = 1840,
          name = "heart",
          type = "",
          shape = "rectangle",
          x = 1808.25,
          y = 790,
          width = 41.75,
          height = 41.75,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {}
        },
        {
          id = 1841,
          name = "feather",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 768,
          width = 50.5,
          height = 67.3333,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
