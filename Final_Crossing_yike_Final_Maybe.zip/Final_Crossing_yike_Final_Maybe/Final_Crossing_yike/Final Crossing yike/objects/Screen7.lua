return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 14,
  nextobjectid = 2707,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 640,
      tileheight = 384,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 59,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        }
      }
    },
    {
      name = "objects",
      firstgid = 140,
      filename = "../objects2.tsx",
      tilewidth = 384,
      tileheight = 384,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 53,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 13,
      name = "sensors",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 2694,
          name = "sensor1",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 224,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 2695,
          name = "sensor2",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 672,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 2696,
          name = "sensor3",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 928,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 5,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1450,
          name = "spikes1",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 224,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1487,
          name = "spikes2",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 672,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1488,
          name = "spikes3",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 928,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1511,
          name = "staticSpikes2",
          type = "",
          shape = "rectangle",
          x = 672,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1512,
          name = "staticSpikes1",
          type = "",
          shape = "rectangle",
          x = 608,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 1594,
          name = "timedSpikes",
          type = "",
          shape = "rectangle",
          x = 1920,
          y = 480,
          width = 128,
          height = 32,
          rotation = -90,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 10,
      name = "brickwork",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 2560,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2561,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2562,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2563,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2564,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2565,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2566,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2568,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2569,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2570,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2571,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1056,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2572,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 1056,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2573,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 672,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2574,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 672,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2575,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 288,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2576,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 288,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2577,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2578,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2581,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2582,
          name = "",
          type = "",
          shape = "rectangle",
          x = 608,
          y = 1024,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2583,
          name = "",
          type = "",
          shape = "rectangle",
          x = 672,
          y = 1024,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2584,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2585,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2586,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 1088,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2587,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 1088,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2588,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2589,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2590,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 1056,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2591,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2592,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 1056,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2593,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 416,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2594,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 800,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2595,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 1056,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2596,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 1088,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2597,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 256,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2598,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376,
          y = 256,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2599,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 256,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2600,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 256,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2601,
          name = "",
          type = "",
          shape = "rectangle",
          x = 608,
          y = 256,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2602,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 256,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2604,
          name = "",
          type = "",
          shape = "rectangle",
          x = 288,
          y = 288,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2605,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2606,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 480,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2607,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 448,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2608,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 416,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2609,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2610,
          name = "",
          type = "",
          shape = "rectangle",
          x = 608,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2611,
          name = "",
          type = "",
          shape = "rectangle",
          x = 640,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2612,
          name = "",
          type = "",
          shape = "rectangle",
          x = 672,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2613,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2614,
          name = "",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2615,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2616,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 910.25,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2617,
          name = "",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2618,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2619,
          name = "",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2620,
          name = "",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 864,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2621,
          name = "",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2622,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 96,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2623,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 64,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2624,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 64,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2625,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 96,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2626,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 992,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2627,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2629,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2630,
          name = "",
          type = "",
          shape = "rectangle",
          x = 896,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2632,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1023.82,
          y = 724.545,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2633,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1055.82,
          y = 724.545,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2634,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1023.83,
          y = 945.333,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2635,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1055.83,
          y = 945.333,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2636,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2637,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2638,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2639,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1151.64,
          y = 719.636,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2640,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1183.64,
          y = 719.636,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2641,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1119.64,
          y = 719.636,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2642,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 928,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2643,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 544,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2644,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1472,
          y = 416,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2645,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 416,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2647,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 416,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2648,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 448,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2649,
          name = "",
          type = "",
          shape = "rectangle",
          x = 704,
          y = 448,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2650,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 576,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2651,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1664,
          y = 576,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2652,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2653,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2654,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2655,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2656,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2657,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2658,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2659,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2660,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2661,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2662,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2663,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2665,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 832,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2666,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2667,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2668,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2669,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1376,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2670,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2671,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2672,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2673,
          name = "",
          type = "",
          shape = "rectangle",
          x = 159.75,
          y = 464,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2674,
          name = "",
          type = "",
          shape = "rectangle",
          x = 223.75,
          y = 464,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2675,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 576,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2676,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 576,
          width = 32,
          height = 16,
          rotation = 0,
          gid = 114,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2677,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1439.94,
          y = 784,
          width = 32,
          height = 16,
          rotation = 0,
          gid = 114,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2678,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1471.94,
          y = 784,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2679,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 896,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2692,
          name = "wall1",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 864,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 2693,
          name = "wall2",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 864,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "rails",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1527,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1192.17,
          y = 156.083,
          width = 128,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1528,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1192.17,
          y = 138.388,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1529,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1208.17,
          y = 301.312,
          width = 32,
          height = 16,
          rotation = 270,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1533,
          name = "",
          type = "",
          shape = "rectangle",
          x = 495.805,
          y = 87.4591,
          width = 32,
          height = 16,
          rotation = 0,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1534,
          name = "",
          type = "",
          shape = "rectangle",
          x = 927.818,
          y = 71.4545,
          width = 416,
          height = 16,
          rotation = -180,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1535,
          name = "",
          type = "",
          shape = "rectangle",
          x = 943.734,
          y = 71.4545,
          width = 32,
          height = 16,
          rotation = -180,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1537,
          name = "",
          type = "",
          shape = "rectangle",
          x = 312.221,
          y = 319.999,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1538,
          name = "",
          type = "",
          shape = "rectangle",
          x = 328.217,
          y = 607.978,
          width = 256,
          height = 16,
          rotation = -90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1539,
          name = "",
          type = "",
          shape = "rectangle",
          x = 328.217,
          y = 639.978,
          width = 32,
          height = 16,
          rotation = -90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1540,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1047.94,
          y = 1009.8,
          width = 32,
          height = 16,
          rotation = -90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1541,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1047.94,
          y = 993.889,
          width = 416,
          height = 16,
          rotation = -90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1542,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1031.94,
          y = 550.5,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1569,
          name = "",
          type = "",
          shape = "rectangle",
          x = 583.851,
          y = 927.929,
          width = 32,
          height = 16,
          rotation = -90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1570,
          name = "",
          type = "",
          shape = "rectangle",
          x = 583.854,
          y = 896,
          width = 448.385,
          height = 16,
          rotation = -90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1571,
          name = "",
          type = "",
          shape = "rectangle",
          x = 567.858,
          y = 415.635,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1577,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1287.81,
          y = 927.981,
          width = 32,
          height = 16,
          rotation = -90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1578,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1287.81,
          y = 896.053,
          width = 352.365,
          height = 16,
          rotation = -90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1579,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1271.81,
          y = 511.688,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1584,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1505.27,
          y = 1034.89,
          width = 32,
          height = 16,
          rotation = -45,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1585,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1516.53,
          y = 1023.63,
          width = 458.234,
          height = 16,
          rotation = -45,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1586,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1850.72,
          y = 666.884,
          width = 32,
          height = 16,
          rotation = 135,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1590,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1532,
          y = 511.989,
          width = 32,
          height = 16,
          rotation = 270,
          gid = 1073741900,
          visible = true,
          properties = {}
        },
        {
          id = 1591,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1516,
          y = 352,
          width = 128,
          height = 16,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1592,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1516,
          y = 320,
          width = 32,
          height = 16,
          rotation = 90,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1595,
          name = "",
          type = "",
          shape = "rectangle",
          x = 848.17,
          y = 408.379,
          width = 32,
          height = 16,
          rotation = -360,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 1596,
          name = "",
          type = "",
          shape = "rectangle",
          x = 880.079,
          y = 408.371,
          width = 392.183,
          height = 16,
          rotation = -360,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 1597,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1304.29,
          y = 392.5,
          width = 32,
          height = 16,
          rotation = -180,
          gid = 1073741900,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 7,
      name = "blades",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1311,
          name = "saw11",
          type = "blades",
          shape = "rectangle",
          x = 1605.17,
          y = 83.8333,
          width = 104.667,
          height = 101.667,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 48
          }
        },
        {
          id = 1312,
          name = "saw0",
          type = "blades",
          shape = "rectangle",
          x = 1152,
          y = 192,
          width = 98,
          height = 98,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 44
          }
        },
        {
          id = 1352,
          name = "saw8",
          type = "blades",
          shape = "rectangle",
          x = 1792,
          y = 736,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 60
          }
        },
        {
          id = 1360,
          name = "saw5",
          type = "blades",
          shape = "rectangle",
          x = 986.184,
          y = 1052.55,
          width = 109,
          height = 109,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 50
          }
        },
        {
          id = 1364,
          name = "saw1",
          type = "blades",
          shape = "rectangle",
          x = 859.984,
          y = 152.545,
          width = 142.395,
          height = 146,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 68
          }
        },
        {
          id = 1407,
          name = "saw6",
          type = "blades",
          shape = "rectangle",
          x = 1481.5,
          y = 371.273,
          width = 84,
          height = 84,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 36
          }
        },
        {
          id = 1448,
          name = "saw10",
          type = "blades",
          shape = "rectangle",
          x = 1399.33,
          y = 281.662,
          width = 99,
          height = 96.1624,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 46
          }
        },
        {
          id = 1474,
          name = "saw2",
          type = "blades",
          shape = "rectangle",
          x = 256,
          y = 392.667,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 60
          }
        },
        {
          id = 1478,
          name = "saw3",
          type = "blades",
          shape = "rectangle",
          x = 512,
          y = 480,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 56
          }
        },
        {
          id = 1500,
          name = "saw9",
          type = "blades",
          shape = "rectangle",
          x = 1227.17,
          y = 564.833,
          width = 105.667,
          height = 105.667,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 46
          }
        },
        {
          id = 1550,
          name = "saw4",
          type = "blades",
          shape = "rectangle",
          x = 1361,
          y = 334.5,
          width = 130,
          height = 130,
          rotation = -180,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 56
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 11,
      name = "interactable",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 2689,
          name = "feather",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 992,
          width = 61.4375,
          height = 81.9167,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {}
        },
        {
          id = 2553,
          name = "exit",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 224,
          width = 95.4375,
          height = 127.25,
          rotation = 0,
          gid = 85,
          visible = true,
          properties = {}
        },
        {
          id = 2554,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1688,
          y = 182.5,
          width = 54,
          height = 54,
          rotation = 0,
          gid = 89,
          visible = true,
          properties = {}
        },
        {
          id = 2688,
          name = "heart",
          type = "",
          shape = "rectangle",
          x = 1814.42,
          y = 990.917,
          width = 52.5,
          height = 52.5,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {}
        },
        {
          id = 1181,
          name = "",
          type = "",
          shape = "text",
          x = 25.7117,
          y = -64,
          width = 407.333,
          height = 62.6667,
          rotation = 0,
          visible = true,
          text = "Screen7",
          pixelsize = 50,
          wrap = true,
          properties = {}
        },
        {
          id = 2690,
          name = "flagYes",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 576,
          width = 48,
          height = 96,
          rotation = 0,
          gid = 98,
          visible = true,
          properties = {}
        },
        {
          id = 2691,
          name = "flagNo",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 576,
          width = 47.8333,
          height = 95.6667,
          rotation = 0,
          gid = 97,
          visible = true,
          properties = {}
        },
        {
          id = 2697,
          name = "",
          type = "",
          shape = "rectangle",
          x = 36.6667,
          y = 267.333,
          width = 24.3333,
          height = 24.3333,
          rotation = 0,
          gid = 214,
          visible = true,
          properties = {}
        },
        {
          id = 2698,
          name = "",
          type = "",
          shape = "rectangle",
          x = 36.6667,
          y = 331.333,
          width = 24.3333,
          height = 24.3333,
          rotation = 0,
          gid = 214,
          visible = true,
          properties = {}
        },
        {
          id = 2699,
          name = "",
          type = "",
          shape = "rectangle",
          x = 804.417,
          y = 1036.83,
          width = 24.3333,
          height = 24.3333,
          rotation = 0,
          gid = 214,
          visible = true,
          properties = {}
        },
        {
          id = 2700,
          name = "",
          type = "",
          shape = "rectangle",
          x = 804.417,
          y = 972.833,
          width = 24.3333,
          height = 24.3333,
          rotation = 0,
          gid = 214,
          visible = true,
          properties = {}
        },
        {
          id = 2701,
          name = "",
          type = "",
          shape = "rectangle",
          x = 805.667,
          y = 779.333,
          width = 24.3333,
          height = 24.3333,
          rotation = 0,
          gid = 214,
          visible = true,
          properties = {}
        },
        {
          id = 2702,
          name = "",
          type = "",
          shape = "rectangle",
          x = 805.667,
          y = 715.333,
          width = 24.3333,
          height = 24.3333,
          rotation = 0,
          gid = 214,
          visible = true,
          properties = {}
        },
        {
          id = 2703,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1891,
          y = 393.333,
          width = 26.6667,
          height = 26.6667,
          rotation = 0,
          gid = 213,
          visible = true,
          properties = {}
        },
        {
          id = 2705,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1891,
          y = 457.333,
          width = 26.6667,
          height = 26.6667,
          rotation = 0,
          gid = 213,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
