return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 14,
  nextobjectid = 672,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 640,
      tileheight = 384,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 59,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        }
      }
    },
    {
      name = "objects",
      firstgid = 140,
      filename = "../objects2.tsx",
      tilewidth = 384,
      tileheight = 384,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 53,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 12,
      name = "sensors",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 630,
          name = "sensor1",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 704,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 631,
          name = "sensor2",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 704,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 632,
          name = "sensor3",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 544,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 633,
          name = "sensor5",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 96,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 634,
          name = "sensor4",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 143.034,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 3,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 601,
          name = "spikes1",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 602,
          name = "spikes2",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 603,
          name = "spikes3",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 604,
          name = "spikes5",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 605,
          name = "spikes4",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 608,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 606,
          name = "spikes6",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 192,
          width = 384,
          height = 32,
          rotation = 90,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 607,
          name = "spikes8",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 544,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 608,
          name = "spikes7",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 512,
          width = 32,
          height = 32,
          rotation = 90,
          gid = 65,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 609,
          name = "spikes9",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 256,
          width = 32,
          height = 32,
          rotation = 90,
          gid = 65,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 610,
          name = "sensorSpikes1",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 640,
          width = 128,
          height = 32,
          rotation = 180,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 611,
          name = "sensorSpikes5",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 96,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 612,
          name = "sensorSpikes4",
          type = "",
          shape = "rectangle",
          x = 543.78,
          y = 271.86,
          width = 128,
          height = 32,
          rotation = -90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 613,
          name = "",
          type = "",
          shape = "rectangle",
          x = 273.517,
          y = 31.8125,
          width = 40,
          height = 60,
          rotation = -270,
          gid = 96,
          visible = true,
          properties = {}
        },
        {
          id = 614,
          name = "sensorSpikes2",
          type = "",
          shape = "rectangle",
          x = 986.136,
          y = 641.909,
          width = 117.091,
          height = 29.25,
          rotation = 180,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 615,
          name = "sensorSpikes3",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 672,
          width = 128,
          height = 32,
          rotation = -90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 616,
          name = "spikes10",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 768,
          width = 128,
          height = 32,
          rotation = 270,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 617,
          name = "spikes11",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 704,
          width = 128,
          height = 32,
          rotation = 270,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 618,
          name = "timedSpikes1",
          type = "",
          shape = "rectangle",
          x = 1280,
          y = -32,
          width = 128,
          height = 52.9091,
          rotation = 180,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 619,
          name = "timedSpikes2",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = -32,
          width = 128,
          height = 52.9091,
          rotation = 180,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 620,
          name = "timedSpikes3",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = -32,
          width = 128,
          height = 52.9091,
          rotation = 180,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 621,
          name = "timedSpikes4",
          type = "",
          shape = "rectangle",
          x = 1664,
          y = -32,
          width = 128,
          height = 52.9091,
          rotation = 180,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 622,
          name = "timedSpikes5",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = -32,
          width = 128,
          height = 52.9091,
          rotation = 180,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 623,
          name = "timedSpikes7",
          type = "",
          shape = "rectangle",
          x = 1056,
          y = 512,
          width = 112,
          height = 32,
          rotation = 0,
          gid = 137,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 624,
          name = "timedSpikes6",
          type = "",
          shape = "rectangle",
          x = 1024,
          y = 928,
          width = 112,
          height = 32,
          rotation = 0,
          gid = 137,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 627,
          name = "saw",
          type = "",
          shape = "rectangle",
          x = 1092.33,
          y = 670.667,
          width = 92,
          height = 92,
          rotation = 0,
          gid = 63,
          visible = true,
          properties = {
            ["bodyType"] = "static",
            ["radius"] = 44
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 11,
      name = "brickwork",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 515,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 516,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 517,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 518,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 519,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 520,
          name = "",
          type = "",
          shape = "rectangle",
          x = 512,
          y = 288,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 521,
          name = "",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 256,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 522,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 523,
          name = "",
          type = "",
          shape = "rectangle",
          x = 512.091,
          y = 300.545,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 524,
          name = "",
          type = "",
          shape = "rectangle",
          x = 608,
          y = 256,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 525,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384.333,
          y = 300.417,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 527,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 192,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 528,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 416,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 529,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 416,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 530,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 544,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 531,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 800,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 532,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 640,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 533,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 672,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 534,
          name = "",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 640,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 535,
          name = "",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 672,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 536,
          name = "",
          type = "",
          shape = "rectangle",
          x = 512,
          y = 608,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 537,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 526.667,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 538,
          name = "",
          type = "",
          shape = "rectangle",
          x = 352,
          y = 526.667,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 539,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 526.667,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 540,
          name = "",
          type = "",
          shape = "rectangle",
          x = 640,
          y = 480,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 541,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832.273,
          y = 367.773,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 542,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 192,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 543,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 192,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 544,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1504,
          y = 192,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 545,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 192,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 546,
          name = "",
          type = "",
          shape = "rectangle",
          x = 960,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 547,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 548,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 416,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 549,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 320,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 551,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 768,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 552,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 1024,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 553,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 384,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 554,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 352,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 555,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 320,
          width = 64,
          height = 16,
          rotation = 0,
          gid = 115,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 557,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 320,
          width = 32,
          height = 16,
          rotation = 0,
          gid = 114,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 558,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 768,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 559,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 768,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 560,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 768,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 561,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 562,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 1024,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 563,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 564,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 565,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 566,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 567,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 568,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 569,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 570,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1024,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 571,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 992,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 572,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 960,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 573,
          name = "",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 960,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 574,
          name = "",
          type = "",
          shape = "rectangle",
          x = 590.727,
          y = 959.455,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 575,
          name = "",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 576,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 577,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 578,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 579,
          name = "",
          type = "",
          shape = "rectangle",
          x = 896,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 580,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1024,
          y = 896,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 581,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1024,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 583,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 584,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1280,
          y = 800,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 585,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1504,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 586,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 587,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 588,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 800,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 589,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1600,
          y = 800,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 590,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1600,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 591,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1600,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 592,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 672,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 593,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 594,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1056,
          y = 480,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 595,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1056,
          y = 512,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 596,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 800,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 629,
          name = "wall1",
          type = "",
          shape = "rectangle",
          x = 1600,
          y = 864,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "interactable",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 450,
          name = "exit2",
          type = "",
          shape = "rectangle",
          x = 1920,
          y = 32,
          width = 64,
          height = 128,
          rotation = 0,
          visible = true,
          properties = {}
        },
        {
          id = 84,
          name = "",
          type = "",
          shape = "text",
          x = 53.71,
          y = -90.6667,
          width = 320.667,
          height = 62.6667,
          rotation = 0,
          visible = true,
          text = "Screen2",
          pixelsize = 50,
          wrap = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 635,
          name = "exit1",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 160,
          width = 82.4444,
          height = 123.667,
          rotation = 0,
          gid = 85,
          visible = true,
          properties = {}
        },
        {
          id = 636,
          name = "exit3",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 992,
          width = 82.4444,
          height = 123.667,
          rotation = 0,
          gid = 85,
          visible = true,
          properties = {}
        },
        {
          id = 637,
          name = "trigger",
          type = "",
          shape = "rectangle",
          x = 1648,
          y = 944,
          width = 16,
          height = 16,
          rotation = 0,
          gid = 131,
          visible = true,
          properties = {}
        },
        {
          id = 638,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1603.75,
          y = 588.5,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 639,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1604,
          y = 652.5,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 640,
          name = "",
          type = "",
          shape = "rectangle",
          x = 515.5,
          y = 253.25,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 641,
          name = "",
          type = "",
          shape = "rectangle",
          x = 515.25,
          y = 189.25,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 642,
          name = "",
          type = "",
          shape = "rectangle",
          x = 547.583,
          y = 204.333,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 643,
          name = "",
          type = "",
          shape = "rectangle",
          x = 547.333,
          y = 140.333,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 644,
          name = "",
          type = "",
          shape = "rectangle",
          x = 500.25,
          y = 665,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 645,
          name = "",
          type = "",
          shape = "rectangle",
          x = 436,
          y = 665,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 646,
          name = "",
          type = "",
          shape = "rectangle",
          x = 883.625,
          y = 668.75,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 647,
          name = "",
          type = "",
          shape = "rectangle",
          x = 947.875,
          y = 668.75,
          width = 24.5,
          height = 24.5,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 648,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1076.25,
          y = 486,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 651,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1140.25,
          y = 486,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 652,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1108.5,
          y = 898.75,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 653,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1044.5,
          y = 898.75,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 654,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1620.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 655,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1556.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 656,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1748.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 657,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1684.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 658,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1492.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 659,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1428.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 660,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1172.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 661,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1236.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 662,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1300.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 663,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1364.09,
          y = 26.8182,
          width = 23.6667,
          height = 23.6667,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 664,
          name = "heart",
          type = "",
          shape = "rectangle",
          x = 905,
          y = 637,
          width = 46,
          height = 46,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {}
        },
        {
          id = 665,
          name = "feather",
          type = "",
          shape = "rectangle",
          x = 1826.18,
          y = 301.818,
          width = 56.3182,
          height = 75.0909,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {}
        },
        {
          id = 666,
          name = "flagNo",
          type = "",
          shape = "rectangle",
          x = 884.438,
          y = 335.955,
          width = 48.125,
          height = 96.25,
          rotation = 0,
          gid = 97,
          visible = true,
          properties = {}
        },
        {
          id = 667,
          name = "flagYes",
          type = "",
          shape = "rectangle",
          x = 884.438,
          y = 335.955,
          width = 48.125,
          height = 96.25,
          rotation = 0,
          gid = 98,
          visible = true,
          properties = {}
        },
        {
          id = 668,
          name = "bullet1",
          type = "",
          shape = "rectangle",
          x = 299.909,
          y = 57.9091,
          width = 7.45455,
          height = 7.45455,
          rotation = 0,
          gid = 138,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 669,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1708.67,
          y = 959,
          width = 51,
          height = 51,
          rotation = 0,
          gid = 86,
          visible = true,
          properties = {}
        },
        {
          id = 513,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1813.5,
          y = 90.5,
          width = 60,
          height = 60,
          rotation = 0,
          gid = 133,
          visible = true,
          properties = {}
        },
        {
          id = 514,
          name = "",
          type = "",
          shape = "rectangle",
          x = 170.167,
          y = 90.1667,
          width = 60,
          height = 60,
          rotation = 0,
          gid = 133,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
