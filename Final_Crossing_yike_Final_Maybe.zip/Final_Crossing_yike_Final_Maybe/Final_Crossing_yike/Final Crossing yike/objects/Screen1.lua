return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 17,
  nextobjectid = 336,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 384,
      tileheight = 384,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 57,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 16,
      name = "sensors",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 254,
          name = "sensor1",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 32,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 132,
          visible = true,
          properties = {}
        },
        {
          id = 236,
          name = "",
          type = "",
          shape = "rectangle",
          x = 486.5,
          y = 969.5,
          width = 58.8,
          height = 42,
          rotation = 0,
          gid = 126,
          visible = true,
          properties = {}
        },
        {
          id = 237,
          name = "",
          type = "",
          shape = "rectangle",
          x = 249.4,
          y = 978.75,
          width = 69.6,
          height = 58,
          rotation = 0,
          gid = 127,
          visible = true,
          properties = {}
        },
        {
          id = 328,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800.745,
          y = 288.125,
          width = 320,
          height = 16,
          rotation = 9.08873,
          gid = 77,
          visible = true,
          properties = {}
        },
        {
          id = 329,
          name = "",
          type = "",
          shape = "rectangle",
          x = 769.147,
          y = 283.071,
          width = 32,
          height = 16,
          rotation = 9.08873,
          gid = 76,
          visible = true,
          properties = {}
        },
        {
          id = 335,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1150.85,
          y = 327.929,
          width = 32,
          height = 16,
          rotation = 189.089,
          gid = 1073741900,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 12,
      name = "brickwork",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 243,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 416,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 244,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 800,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 245,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 246,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 247,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1824,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 248,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1856,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 255,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 192,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 262,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1312,
          y = 384,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 269,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 544,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 270,
          name = "",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 544,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 271,
          name = "",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 544,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 272,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1184,
          y = 544,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 277,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 279,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 280,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 832,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 281,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1344,
          y = 704,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 282,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1503.75,
          y = 496.75,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 283,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 608,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 290,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1056,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 291,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 292,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 293,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 294,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 1024,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 295,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 108,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 296,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 297,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 298,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 299,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 1088,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 300,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 301,
          name = "",
          type = "",
          shape = "rectangle",
          x = 832,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 302,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 303,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1312,
          y = 1056,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 307,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 308,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 309,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1728,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 310,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1696,
          y = 896,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 311,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 896,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 312,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 313,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 960,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 314,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 315,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 1024,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 316,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1664,
          y = 992,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 317,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1728,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 318,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1696,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 319,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1696,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 320,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 323,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 288,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 324,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 320,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 104,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 226,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 1056,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 304,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 992,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 305,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 992,
          width = 256,
          height = 32,
          rotation = 0,
          gid = 94,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 306,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 864,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 239,
          name = "",
          type = "",
          shape = "rectangle",
          x = 384,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 240,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 241,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 242,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 227,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 704,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 228,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 672,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 229,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 640,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 230,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 608,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 231,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 576,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 232,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 800,
          width = 32,
          height = 256,
          rotation = 0,
          gid = 110,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 233,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 704,
          width = 32,
          height = 128,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 234,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 103,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 238,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 106,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 260,
          name = "",
          type = "",
          shape = "rectangle",
          x = 480,
          y = 224,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 93,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 263,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 800,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 273,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 928,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 259,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 416,
          width = 32,
          height = 384,
          rotation = 0,
          gid = 111,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 7,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 325,
          name = "timedSpikes",
          type = "",
          shape = "rectangle",
          x = 1583.75,
          y = 319.5,
          width = 112,
          height = 32,
          rotation = 0,
          gid = 137,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 253,
          name = "sensorSpikes",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 128,
          height = 32,
          rotation = 90,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 265,
          name = "spikes5",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 512,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 266,
          name = "spikes4",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 512,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 267,
          name = "spikes3",
          type = "",
          shape = "rectangle",
          x = 800,
          y = 512,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 268,
          name = "spikes2",
          type = "",
          shape = "rectangle",
          x = 1056,
          y = 512,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 249,
          name = "spikes1",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 160,
          width = 128,
          height = 32,
          rotation = 270,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 10,
      name = "interactable",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 87,
          name = "exit",
          type = "exits",
          shape = "rectangle",
          x = 1952,
          y = 790.667,
          width = 64,
          height = 233.333,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 222,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 960,
          width = 128,
          height = 64,
          rotation = 0,
          gid = 134,
          visible = true,
          properties = {}
        },
        {
          id = 223,
          name = "",
          type = "",
          shape = "rectangle",
          x = 288,
          y = 960,
          width = 64,
          height = 96,
          rotation = 0,
          gid = 136,
          visible = true,
          properties = {}
        },
        {
          id = 224,
          name = "",
          type = "",
          shape = "rectangle",
          x = 352,
          y = 960,
          width = 64,
          height = 96,
          rotation = 0,
          gid = 136,
          visible = true,
          properties = {}
        },
        {
          id = 225,
          name = "",
          type = "",
          shape = "rectangle",
          x = 416,
          y = 960,
          width = 64,
          height = 96,
          rotation = 0,
          gid = 136,
          visible = true,
          properties = {}
        },
        {
          id = 235,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 864,
          width = 224,
          height = 96,
          rotation = 0,
          gid = 135,
          visible = true,
          properties = {}
        },
        {
          id = 261,
          name = "mov1",
          type = "",
          shape = "rectangle",
          x = 1088,
          y = 352,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 79,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 326,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1584.33,
          y = 303,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 327,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1648.33,
          y = 303,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 74,
          visible = true,
          properties = {}
        },
        {
          id = 250,
          name = "feather",
          type = "",
          shape = "rectangle",
          x = 1792,
          y = 160,
          width = 51.8333,
          height = 69.1111,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {}
        },
        {
          id = 256,
          name = "heart",
          type = "",
          shape = "rectangle",
          x = 132,
          y = 157,
          width = 50,
          height = 50,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {}
        },
        {
          id = 321,
          name = "flagYes",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 672,
          width = 47.6667,
          height = 95.3333,
          rotation = 0,
          gid = 98,
          visible = true,
          properties = {}
        },
        {
          id = 322,
          name = "flagNo",
          type = "",
          shape = "rectangle",
          x = 1536,
          y = 672,
          width = 47.8333,
          height = 95.6667,
          rotation = 0,
          gid = 97,
          visible = true,
          properties = {}
        },
        {
          id = 257,
          name = "",
          type = "",
          shape = "rectangle",
          x = 3,
          y = 77,
          width = 25.6667,
          height = 25.6667,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        },
        {
          id = 258,
          name = "",
          type = "",
          shape = "rectangle",
          x = 3,
          y = 138.333,
          width = 25.6667,
          height = 25.6667,
          rotation = 0,
          gid = 75,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
