return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 7,
  nextobjectid = 62,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 1033,
      tileheight = 658,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 76,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        },
        {
          id = 139,
          image = "asjadj.png",
          width = 128,
          height = 128
        },
        {
          id = 140,
          image = "asjadj_smaller.png",
          width = 96,
          height = 128
        },
        {
          id = 141,
          image = "Background2.png",
          width = 1033,
          height = 581
        },
        {
          id = 142,
          image = "CLIFF1.png",
          width = 96,
          height = 128
        },
        {
          id = 143,
          image = "CLIFF2.png",
          width = 128,
          height = 128
        },
        {
          id = 144,
          image = "dirt2.png",
          width = 32,
          height = 32
        },
        {
          id = 145,
          image = "floorPalace.png",
          width = 32,
          height = 32
        },
        {
          id = 146,
          image = "green.png",
          width = 32,
          height = 32
        },
        {
          id = 147,
          image = "green_top.png",
          width = 32,
          height = 32
        },
        {
          id = 148,
          image = "green2.png",
          width = 32,
          height = 32
        },
        {
          id = 149,
          image = "l_o_n_g.png",
          width = 59,
          height = 658
        },
        {
          id = 150,
          image = "oop.png",
          width = 352,
          height = 256
        },
        {
          id = 151,
          image = "oop2.png",
          width = 352,
          height = 256
        },
        {
          id = 152,
          image = "wallPALACE.png",
          width = 32,
          height = 32
        },
        {
          id = 153,
          image = "Window.png",
          width = 192,
          height = 416
        },
        {
          id = 154,
          image = "exitSurface.png",
          width = 64,
          height = 32
        },
        {
          id = 155,
          image = "platform3SMALL.png",
          width = 96,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 2,
      name = "background",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 1,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 1919.97,
          height = 1088.02,
          rotation = 0,
          gid = 142,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 3,
      name = "game",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 49,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 0,
          y = -32,
          width = 1920,
          height = 32,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 50,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1920,
          y = 576,
          width = 32,
          height = 448,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 5,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 289.667,
          height = 318,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 6,
          name = "",
          type = "",
          shape = "rectangle",
          x = 288,
          y = 1088,
          width = 353.667,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 7,
          name = "",
          type = "",
          shape = "rectangle",
          x = 640,
          y = 1088,
          width = 289.667,
          height = 192,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 17,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 960,
          width = 161.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 18,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1216,
          y = 896,
          width = 161.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 26,
          name = "",
          type = "",
          shape = "rectangle",
          x = 768,
          y = 672,
          width = 161.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 27,
          name = "",
          type = "",
          shape = "rectangle",
          x = 544,
          y = 576,
          width = 161.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 28,
          name = "",
          type = "",
          shape = "rectangle",
          x = 896,
          y = 512,
          width = 161.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 29,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1152,
          y = 448,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 30,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 576,
          width = 354.167,
          height = 191,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 55,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1280,
          y = 448,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 56,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1408,
          y = 448,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 57,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1120,
          y = 704,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 58,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 704,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 59,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 704,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 60,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1504,
          y = 832,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 61,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 832,
          width = 130.667,
          height = 32.3333,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 41,
          name = "spikes1",
          type = "spikes",
          shape = "rectangle",
          x = 928,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 42,
          name = "spikes2",
          type = "spikes",
          shape = "rectangle",
          x = 1056,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 43,
          name = "spikes3",
          type = "spikes",
          shape = "rectangle",
          x = 1184,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 44,
          name = "spikes4",
          type = "spikes",
          shape = "rectangle",
          x = 1312,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 45,
          name = "spikes7",
          type = "spikes",
          shape = "rectangle",
          x = 1696,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 46,
          name = "spikes8",
          type = "spikes",
          shape = "rectangle",
          x = 1792,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 47,
          name = "spikes6",
          type = "spikes",
          shape = "rectangle",
          x = 1568,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 48,
          name = "spikes5",
          type = "spikes",
          shape = "rectangle",
          x = 1440,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 70,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 5,
      name = "exits",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 38,
          name = "exit1",
          type = "exits",
          shape = "rectangle",
          x = 1920,
          y = 0,
          width = 32,
          height = 384,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 39,
          name = "",
          type = "exits",
          shape = "rectangle",
          x = -32,
          y = 0,
          width = 32,
          height = 768,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 6,
      name = "enemies",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 52,
          name = "goose1",
          type = "enemy",
          shape = "rectangle",
          x = 1728,
          y = 384,
          width = 96.5,
          height = 127,
          rotation = 0,
          gid = 123,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 53,
          name = "goose2",
          type = "enemy",
          shape = "rectangle",
          x = 1248,
          y = 672,
          width = 96,
          height = 125.667,
          rotation = 0,
          gid = 121,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    }
  }
}
