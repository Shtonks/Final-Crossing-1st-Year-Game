return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 11,
  nextobjectid = 873,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 1033,
      tileheight = 658,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 76,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        },
        {
          id = 139,
          image = "asjadj.png",
          width = 128,
          height = 128
        },
        {
          id = 140,
          image = "asjadj_smaller.png",
          width = 96,
          height = 128
        },
        {
          id = 141,
          image = "Background2.png",
          width = 1033,
          height = 581
        },
        {
          id = 142,
          image = "CLIFF1.png",
          width = 96,
          height = 128
        },
        {
          id = 143,
          image = "CLIFF2.png",
          width = 128,
          height = 128
        },
        {
          id = 144,
          image = "dirt2.png",
          width = 32,
          height = 32
        },
        {
          id = 145,
          image = "floorPalace.png",
          width = 32,
          height = 32
        },
        {
          id = 146,
          image = "green.png",
          width = 32,
          height = 32
        },
        {
          id = 147,
          image = "green_top.png",
          width = 32,
          height = 32
        },
        {
          id = 148,
          image = "green2.png",
          width = 32,
          height = 32
        },
        {
          id = 149,
          image = "l_o_n_g.png",
          width = 59,
          height = 658
        },
        {
          id = 150,
          image = "oop.png",
          width = 352,
          height = 256
        },
        {
          id = 151,
          image = "oop2.png",
          width = 352,
          height = 256
        },
        {
          id = 152,
          image = "wallPALACE.png",
          width = 32,
          height = 32
        },
        {
          id = 153,
          image = "Window.png",
          width = 192,
          height = 416
        },
        {
          id = 154,
          image = "exitSurface.png",
          width = 64,
          height = 32
        },
        {
          id = 155,
          image = "platform3SMALL.png",
          width = 96,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      id = 10,
      name = "Background",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 855,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 544,
          width = 192,
          height = 416,
          rotation = 0,
          gid = 154,
          visible = true,
          properties = {}
        },
        {
          id = 860,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 544,
          width = 192,
          height = 416,
          rotation = 0,
          gid = 154,
          visible = true,
          properties = {}
        },
        {
          id = 861,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 544,
          width = 192,
          height = 416,
          rotation = 0,
          gid = 154,
          visible = true,
          properties = {}
        },
        {
          id = 862,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 1056,
          width = 59,
          height = 504.667,
          rotation = 0,
          gid = 150,
          visible = true,
          properties = {}
        },
        {
          id = 863,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224,
          y = 1056,
          width = 59,
          height = 498,
          rotation = 0,
          gid = 150,
          visible = true,
          properties = {}
        },
        {
          id = 864,
          name = "",
          type = "",
          shape = "rectangle",
          x = 864,
          y = 1056,
          width = 59,
          height = 512,
          rotation = 0,
          gid = 150,
          visible = true,
          properties = {}
        },
        {
          id = 865,
          name = "",
          type = "",
          shape = "rectangle",
          x = 992,
          y = 1056,
          width = 59,
          height = 512.667,
          rotation = 0,
          gid = 150,
          visible = true,
          properties = {}
        },
        {
          id = 866,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1632,
          y = 1088,
          width = 59,
          height = 545,
          rotation = 0,
          gid = 150,
          visible = true,
          properties = {}
        },
        {
          id = 867,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1760,
          y = 1088,
          width = 59,
          height = 544.5,
          rotation = 0,
          gid = 150,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 199,
          name = "spikes3",
          type = "spikes",
          shape = "rectangle",
          x = 640,
          y = 768,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 200,
          name = "spikes2",
          type = "spikes",
          shape = "rectangle",
          x = 448,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 201,
          name = "spikes1",
          type = "spikes",
          shape = "rectangle",
          x = 64,
          y = 1056,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 202,
          name = "spikes7",
          type = "spikes",
          shape = "rectangle",
          x = 960,
          y = 224,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 203,
          name = "spikes6",
          type = "spikes",
          shape = "rectangle",
          x = 576,
          y = 224,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 204,
          name = "spikes5",
          type = "spikes",
          shape = "rectangle",
          x = 448,
          y = 224,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 64,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 205,
          name = "spikes4",
          type = "spikes",
          shape = "rectangle",
          x = 672,
          y = 480,
          width = 384,
          height = 32,
          rotation = 0,
          gid = 100,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 5,
      name = "moving platforms",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 222,
          name = "platform1",
          type = "ground",
          shape = "rectangle",
          x = 96,
          y = 960,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 212,
          name = "platform2",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 480,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 217,
          name = "platform5",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 704,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 219,
          name = "platform6",
          type = "ground",
          shape = "rectangle",
          x = 1120,
          y = 992,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 214,
          name = "platform4",
          type = "ground",
          shape = "rectangle",
          x = 1024,
          y = 448,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 227,
          name = "platform7",
          type = "ground",
          shape = "rectangle",
          x = 1344,
          y = 896,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 225,
          name = "platform8",
          type = "ground",
          shape = "rectangle",
          x = 1760.36,
          y = 944,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 210,
          name = "platform3",
          type = "ground",
          shape = "rectangle",
          x = 320,
          y = 192,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 156,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 6,
      name = "turrets",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 230,
          name = "turret6",
          type = "turret",
          shape = "rectangle",
          x = 1710,
          y = 1056.67,
          width = 40,
          height = 60,
          rotation = 270,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 231,
          name = "turret5",
          type = "turret",
          shape = "rectangle",
          x = 1600,
          y = 800,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 232,
          name = "turret4",
          type = "turret",
          shape = "rectangle",
          x = 1600,
          y = 672,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 233,
          name = "turret3",
          type = "turret",
          shape = "rectangle",
          x = 1600,
          y = 544,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 234,
          name = "turret1",
          type = "turret",
          shape = "rectangle",
          x = 1792,
          y = 224,
          width = 40,
          height = 60,
          rotation = 90,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 235,
          name = "turret2",
          type = "turret",
          shape = "rectangle",
          x = 1888,
          y = 256,
          width = 40,
          height = 60,
          rotation = 180,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 238,
          name = "turret9",
          type = "turret",
          shape = "rectangle",
          x = 936.667,
          y = 240,
          width = 40,
          height = 60,
          rotation = -270,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 239,
          name = "turret8",
          type = "turret",
          shape = "rectangle",
          x = 1169.33,
          y = 240,
          width = 40,
          height = 60,
          rotation = -270,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 240,
          name = "turret10",
          type = "turret",
          shape = "rectangle",
          x = 480,
          y = 672,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 241,
          name = "turret14",
          type = "turret",
          shape = "rectangle",
          x = 33,
          y = 1015.33,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 242,
          name = "turret13",
          type = "turret",
          shape = "rectangle",
          x = 92.6667,
          y = 676.333,
          width = 40,
          height = 60,
          rotation = 41.0746,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 243,
          name = "turret12",
          type = "turret",
          shape = "rectangle",
          x = 32,
          y = 416,
          width = 40,
          height = 60,
          rotation = 0,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 244,
          name = "turret11",
          type = "turret",
          shape = "rectangle",
          x = 96,
          y = 32,
          width = 40,
          height = 60,
          rotation = -270,
          gid = 96,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 7,
      name = "collectables",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 148,
          name = "feather",
          type = "collectables",
          shape = "rectangle",
          x = 512,
          y = 768,
          width = 84.6667,
          height = 112.889,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 197,
          name = "heart",
          type = "collectables",
          shape = "rectangle",
          x = 538.5,
          y = 348,
          width = 43.5,
          height = 43.5,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 260,
          name = "heart",
          type = "collectables",
          shape = "rectangle",
          x = 1800,
          y = 192,
          width = 43.5,
          height = 43.5,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 8,
      name = "exits",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 151,
          name = "exit1",
          type = "exits",
          shape = "rectangle",
          x = 864,
          y = 1056,
          width = 64,
          height = 96,
          rotation = 0,
          gid = 155,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 3,
      name = "outerwall",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 246,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 32.9623,
          y = 745.081,
          width = 225.014,
          height = 16,
          rotation = 311.071,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 133,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 137.396,
          y = 757.944,
          width = 32,
          height = 32,
          rotation = 311.972,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 132,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 116.095,
          y = 781.688,
          width = 32,
          height = 32,
          rotation = 311.909,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 135,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 196.706,
          y = 695.209,
          width = 32,
          height = 32,
          rotation = 311.302,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 731,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 217.75,
          y = 671.313,
          width = 32,
          height = 32,
          rotation = 311.302,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 732,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 238.854,
          y = 647.312,
          width = 32,
          height = 32,
          rotation = -48.698,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 733,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 259.982,
          y = 623.276,
          width = 32,
          height = 32,
          rotation = 311.302,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 734,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 281.043,
          y = 599.285,
          width = 32,
          height = 32,
          rotation = 311.302,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 739,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 94.7591,
          y = 805.431,
          width = 32,
          height = 32,
          rotation = 311.909,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 740,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 73.3913,
          y = 829.215,
          width = 32,
          height = 32,
          rotation = 311.909,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 741,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 52.163,
          y = 852.946,
          width = 32,
          height = 32,
          rotation = 311.909,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 742,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 30.8577,
          y = 876.636,
          width = 32,
          height = 32,
          rotation = 311.909,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 2,
      name = "game",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {
        ["bodyType"] = "static"
      },
      objects = {
        {
          id = 162,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1600,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 169,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 170,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 171,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 172,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 672,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 173,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 736,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 174,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 800,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 175,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 176,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 177,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 178,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1056,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 179,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1120,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 180,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1184,
          y = 240,
          width = 128,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 181,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 240,
          width = 98,
          height = 16,
          rotation = 0,
          gid = 77,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 182,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1344.5,
          y = 224,
          width = 32.5,
          height = 16,
          rotation = 180,
          gid = 1073741938,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 184,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 92,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 194,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 195,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 196,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 220,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 672,
          y = 1024,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 80,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 221,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 320,
          y = 1024,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 80,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 226,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1504,
          y = 992,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 80,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 142,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 434.87,
          y = 737.803,
          width = 32,
          height = 32,
          rotation = 41.7487,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 258,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1329.21,
          y = 191.958,
          width = 32,
          height = 16.875,
          rotation = 90,
          gid = 1073741901,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 261,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1663.64,
          y = 338.424,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 262,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1631.64,
          y = 338.424,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 263,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1599.64,
          y = 338.424,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 264,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1856,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 265,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1824,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 266,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1792,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 270,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1760,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 271,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1344,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 272,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1312,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 273,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1280,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 274,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 275,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1440,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 276,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1408,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 277,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1376,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 278,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1536,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 279,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1504,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 280,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1472,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 281,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1536,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 282,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1504,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 283,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1472,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 284,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 736,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 285,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 704,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 286,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 672,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 287,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 288,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 289,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 800,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 290,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 768,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 291,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 960,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 292,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 293,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 896,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 294,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 295,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1056,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 296,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1024,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 297,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 298,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 299,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 300,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 301,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 304,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 305,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 306,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 307,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 308,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 309,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 310,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 311,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 312,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 313,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 314,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 315,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 316,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 317,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 318,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 319,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 320,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 321,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 322,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 323,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 324,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 325,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 326,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 327,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 328,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 329,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 330,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 331,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 332,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 333,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 334,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 335,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 336,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 337,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 338,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 339,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 340,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 341,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 672,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 342,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 343,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 344,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 800,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 345,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 768,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 346,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 736,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 347,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 704,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 348,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 896,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 349,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 350,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 351,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 352,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 960,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 353,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 354,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 355,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 356,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 960,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 357,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 358,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 896,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 359,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 360,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 1056,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 363,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 992,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 534,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1472,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 535,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1440,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 536,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1408,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 537,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1376,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 538,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1568,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 539,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1536,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 540,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1504,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 541,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1696,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 542,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1664,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 543,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1632,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 544,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1600,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 545,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1792,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 546,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1760,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 547,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1728,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 548,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1888,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 549,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1856,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 550,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1824,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 551,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 552,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 896,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 553,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 554,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 555,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1024,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 556,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 557,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 960,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 558,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1152,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 559,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1120,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 560,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1088,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 561,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1056,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 562,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 563,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1216,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 564,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1184,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 565,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1344,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 566,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1312,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 567,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1280,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 568,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 569,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 570,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 320,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 571,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 288,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 572,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 573,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 574,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 575,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 576,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 577,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 578,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 579,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 704,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 580,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 672,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 581,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 582,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 800,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 583,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 768,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 584,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 736,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 592,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 64,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 593,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 32,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 594,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 596,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 160,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 597,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 128,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 598,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 96,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 599,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 256,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 600,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 224,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 601,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 192,
          y = 1088,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 602,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1472,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 603,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1440,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 604,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1408,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 605,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1376,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 606,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1568,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 607,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1536,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 608,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1504,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 609,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1696,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 610,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1664,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 611,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1632,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 612,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1600,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 613,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1792,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 614,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1760,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 615,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1728,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 616,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1888,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 617,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1856,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 618,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1824,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 619,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 928,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 620,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 896,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 621,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 622,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 623,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1024,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 624,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 625,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 960,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 626,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1152,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 627,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1120,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 628,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1088,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 629,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1056,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 630,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 631,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1216,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 632,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1184,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 633,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1344,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 634,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1312,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 635,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1280,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 636,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 637,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 638,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 320,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 639,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 288,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 640,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 641,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 642,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 643,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 644,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 576,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 645,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 646,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 647,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 704,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 648,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 672,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 649,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 650,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 800,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 651,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 768,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 652,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 736,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 653,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 64,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 654,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 32,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 655,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 656,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 160,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 657,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 128,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 658,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 96,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 659,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 256,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 660,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 224,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 661,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 192,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 694,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 64,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 695,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 96,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 696,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 128,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 697,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 160,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 698,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 699,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 700,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 701,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 702,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 320,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 703,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 352,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 704,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 705,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 706,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 707,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 708,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 768,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 709,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 710,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 711,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 712,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 896,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 713,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 714,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 715,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 992,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 716,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 717,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1056,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 718,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 719,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 720,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 721,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 722,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 723,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 724,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 725,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 726,
          name = "",
          type = "",
          shape = "rectangle",
          x = 160,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 727,
          name = "",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 728,
          name = "",
          type = "",
          shape = "rectangle",
          x = 224,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 729,
          name = "",
          type = "",
          shape = "rectangle",
          x = 256,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 730,
          name = "",
          type = "",
          shape = "rectangle",
          x = 288,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 743,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 744,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 745,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 746,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 747,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 748,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 749,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 750,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 751,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 413.723,
          y = 761.411,
          width = 32,
          height = 32,
          rotation = 41.7487,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 752,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 392.685,
          y = 784.965,
          width = 32,
          height = 32,
          rotation = 41.7487,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 753,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 371.907,
          y = 808.423,
          width = 32,
          height = 32,
          rotation = 41.7487,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 754,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 350.932,
          y = 831.826,
          width = 32,
          height = 32,
          rotation = 41.7487,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 756,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 757,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 758,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 759,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 760,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 761,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 762,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 763,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 764,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 765,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 766,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 767,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 768,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 769,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 770,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 320,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 771,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 352,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 772,
          name = "",
          type = "",
          shape = "rectangle",
          x = 32,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 773,
          name = "",
          type = "",
          shape = "rectangle",
          x = 64,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 774,
          name = "",
          type = "",
          shape = "rectangle",
          x = 96,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 775,
          name = "",
          type = "",
          shape = "rectangle",
          x = 128,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 146,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 777,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 778,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 779,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 780,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 781,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 782,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 768,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 783,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 784,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 785,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 786,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 896,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 787,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 788,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 789,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 992,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 790,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 791,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 792,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 793,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1248,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 794,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 1056,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 795,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1888,
          y = 1024,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 796,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 797,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 798,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 799,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 800,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 768,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 801,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 802,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 832,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 803,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 864,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 804,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 896,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 805,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 928,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 806,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 960,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 807,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 992,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 808,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 809,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 810,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 811,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 812,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1888,
          y = 1056,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 813,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1888,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 814,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 64,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 815,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 96,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 816,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 128,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 817,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 160,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 818,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 819,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 820,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 821,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 822,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 320,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 823,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 352,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 824,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 825,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1888,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 830,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1888,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 831,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1568,
          y = 576,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 832,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 192,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 833,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 224,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 834,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 256,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 835,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 288,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 836,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 320,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 837,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 352,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 838,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 384,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 839,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 416,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 840,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 841,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 842,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 843,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 844,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 64,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 845,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 96,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 846,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 128,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 847,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 160,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 848,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1568,
          y = 608,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 849,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 850,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 672,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 851,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 704,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 852,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 736,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 853,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 768,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 854,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1568,
          y = 800,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 869,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 448,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 870,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 480,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 871,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 512,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 872,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 544,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 153,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 9,
      name = "platforms",
      visible = false,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 51,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 96,
          y = 928,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = 256, y = -288 }
          },
          properties = {}
        },
        {
          id = 223,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 672,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 50,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 352,
          y = 448,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = -64, y = -128 }
          },
          properties = {}
        },
        {
          id = 211,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 288,
          y = 352,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 46,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 288,
          y = 192,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = 1024, y = 0 }
          },
          properties = {}
        },
        {
          id = 213,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1312,
          y = 192,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 56,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 1024,
          y = 448,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = -192, y = 0 }
          },
          properties = {}
        },
        {
          id = 215,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 448,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 80,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 928,
          y = 704,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = -288, y = 0 }
          },
          properties = {}
        },
        {
          id = 218,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 704,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 57,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 1120,
          y = 960,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = 0, y = -416 }
          },
          properties = {}
        },
        {
          id = 216,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1120,
          y = 544,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 47,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 1345,
          y = 862.333,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = -1, y = -190.333 }
          },
          properties = {}
        },
        {
          id = 228,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1344,
          y = 704,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 48,
          name = "",
          type = "ground",
          shape = "polyline",
          x = 1760,
          y = 416,
          width = 0,
          height = 0,
          rotation = 0,
          visible = true,
          polyline = {
            { x = 0, y = 0 },
            { x = 1, y = 494 }
          },
          properties = {}
        },
        {
          id = 224,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1760,
          y = 448,
          width = 96,
          height = 32,
          rotation = 0,
          gid = 90,
          visible = true,
          properties = {}
        },
        {
          id = 237,
          name = "turret7",
          type = "turret",
          shape = "rectangle",
          x = 1568,
          y = 96,
          width = 40,
          height = 60,
          rotation = 180,
          gid = 96,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
