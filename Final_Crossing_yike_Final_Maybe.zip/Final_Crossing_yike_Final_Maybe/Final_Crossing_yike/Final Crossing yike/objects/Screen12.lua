return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 10,
  nextobjectid = 841,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 1033,
      tileheight = 658,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 76,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        },
        {
          id = 139,
          image = "asjadj.png",
          width = 128,
          height = 128
        },
        {
          id = 140,
          image = "asjadj_smaller.png",
          width = 96,
          height = 128
        },
        {
          id = 141,
          image = "Background2.png",
          width = 1033,
          height = 581
        },
        {
          id = 142,
          image = "CLIFF1.png",
          width = 96,
          height = 128
        },
        {
          id = 143,
          image = "CLIFF2.png",
          width = 128,
          height = 128
        },
        {
          id = 144,
          image = "dirt2.png",
          width = 32,
          height = 32
        },
        {
          id = 145,
          image = "floorPalace.png",
          width = 32,
          height = 32
        },
        {
          id = 146,
          image = "green.png",
          width = 32,
          height = 32
        },
        {
          id = 147,
          image = "green_top.png",
          width = 32,
          height = 32
        },
        {
          id = 148,
          image = "green2.png",
          width = 32,
          height = 32
        },
        {
          id = 149,
          image = "l_o_n_g.png",
          width = 59,
          height = 658
        },
        {
          id = 150,
          image = "oop.png",
          width = 352,
          height = 256
        },
        {
          id = 151,
          image = "oop2.png",
          width = 352,
          height = 256
        },
        {
          id = 152,
          image = "wallPALACE.png",
          width = 32,
          height = 32
        },
        {
          id = 153,
          image = "Window.png",
          width = 192,
          height = 416
        },
        {
          id = 154,
          image = "exitSurface.png",
          width = 64,
          height = 32
        },
        {
          id = 155,
          image = "platform3SMALL.png",
          width = 96,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      id = 1,
      name = "Tile Layer 1",
      x = 0,
      y = 0,
      width = 60,
      height = 34,
      visible = false,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "objectgroup",
      id = 6,
      name = "background",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 342,
          name = "",
          type = "",
          shape = "rectangle",
          x = -2,
          y = 1080,
          width = 1920,
          height = 1080,
          rotation = 0,
          gid = 142,
          visible = true,
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      id = 3,
      name = "game",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 762,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = -96,
          y = 1120,
          width = 352,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 763,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 1088,
          width = 576.167,
          height = 352,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 764,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 896,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 766,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1696,
          y = 1216,
          width = 352,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 767,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1344,
          y = 1216,
          width = 352,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 768,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 1216,
          width = 352,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 777,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1376,
          y = 319.667,
          width = 128,
          height = 95.6667,
          rotation = 0,
          gid = 140,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 778,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1248,
          y = 319.75,
          width = 128,
          height = 95.75,
          rotation = 0,
          gid = 140,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 779,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1120,
          y = 319.75,
          width = 128,
          height = 95.75,
          rotation = 0,
          gid = 140,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 780,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 992,
          y = 319.25,
          width = 128,
          height = 95.25,
          rotation = 0,
          gid = 140,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 781,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 864,
          y = 319.75,
          width = 128,
          height = 95.75,
          rotation = 0,
          gid = 140,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 782,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1600,
          y = 352,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 783,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1504,
          y = 576,
          width = 128.667,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 784,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1280,
          y = 640,
          width = 126.667,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 787,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1792,
          y = 608,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 144,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 788,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 640,
          y = 1216,
          width = 352,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 794,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1920,
          y = 0,
          width = 32,
          height = 480,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 795,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = -32,
          width = 1921.33,
          height = 32,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 796,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1216,
          y = 960,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 144,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 797,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 864,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 798,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 864,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 799,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 864,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 800,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 864,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 801,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 864,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 802,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 896,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 803,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 896,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 804,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 896,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 805,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 896,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 806,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 960,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 807,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 928,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 808,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 928,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 809,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 928,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 810,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 928,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 811,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 928,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 812,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 960,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 813,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 960,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 814,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 960,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 815,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 960,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 816,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 1024,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 817,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 992,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 818,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 992,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 819,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 992,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 820,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 992,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 821,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 992,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 822,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 1024,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 823,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 1024,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 824,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 1024,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 825,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 1024,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 826,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 1088,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 827,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 1056,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 828,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 1056,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 829,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 1056,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 830,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 1056,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 831,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 1056,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 832,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 1088,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 833,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 1088,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 834,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 1088,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 835,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 1088,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 145,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 836,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 384,
          y = 832,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 147,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 837,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 416,
          y = 832,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 147,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 838,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 832,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 147,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 839,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 512,
          y = 800,
          width = 31.9795,
          height = 32.0455,
          rotation = 180,
          gid = 1073741972,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 840,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 832,
          width = 31.9795,
          height = 32.0455,
          rotation = 0,
          gid = 148,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "collectables",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 72,
          name = "heart",
          type = "collectables",
          shape = "rectangle",
          x = 896,
          y = 224,
          width = 64,
          height = 64.3333,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 775,
          name = "feather",
          type = "collectables",
          shape = "rectangle",
          x = 992,
          y = 224,
          width = 96,
          height = 128,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 7,
      name = "holes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 789,
          name = "hole",
          type = "hole",
          shape = "rectangle",
          x = 256,
          y = 1120,
          width = 380,
          height = 32,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 9,
      name = "exits",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 791,
          name = "",
          type = "exits",
          shape = "rectangle",
          x = -32,
          y = 0,
          width = 32,
          height = 896,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 793,
          name = "exit1",
          type = "exits",
          shape = "rectangle",
          x = 1920,
          y = 607,
          width = 32,
          height = 289,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 8,
      name = "enemies",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 46,
          name = "goose1",
          type = "enemy",
          shape = "rectangle",
          x = 960,
          y = 736,
          width = 95.8424,
          height = 127.5,
          rotation = 0,
          gid = 121,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 773,
          name = "goose2",
          type = "enemy",
          shape = "rectangle",
          x = 1792,
          y = 960,
          width = 94,
          height = 128,
          rotation = 0,
          gid = 123,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 774,
          name = "goose3",
          type = "enemy",
          shape = "rectangle",
          x = 1184,
          y = 96,
          width = 94,
          height = 128,
          rotation = 180,
          gid = 1073741947,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    }
  }
}
