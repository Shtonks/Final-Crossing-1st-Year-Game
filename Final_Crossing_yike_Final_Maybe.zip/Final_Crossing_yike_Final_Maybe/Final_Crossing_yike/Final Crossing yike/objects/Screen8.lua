return {
  version = "1.2",
  luaversion = "5.1",
  tiledversion = "1.3.3",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 60,
  height = 34,
  tilewidth = 32,
  tileheight = 32,
  nextlayerid = 7,
  nextobjectid = 65,
  properties = {},
  tilesets = {
    {
      name = "objects",
      firstgid = 2,
      filename = "../objects.tsx",
      tilewidth = 1033,
      tileheight = 658,
      spacing = 0,
      margin = 0,
      columns = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 76,
      tiles = {
        {
          id = 62,
          image = "circular blade.png",
          width = 62,
          height = 62
        },
        {
          id = 63,
          image = "spikesx4.png",
          width = 128,
          height = 32
        },
        {
          id = 64,
          image = "spikex1.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "spikeSensorx1.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "spikeSensorx4.png",
          width = 128,
          height = 32
        },
        {
          id = 68,
          image = "spikesTimedx1.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "spikesTimedx4.png",
          width = 128,
          height = 32
        },
        {
          id = 72,
          image = "battery.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "dangoo.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "dangoo2.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "ENDBAR.png",
          width = 32,
          height = 16
        },
        {
          id = 76,
          image = "MIDDLEBAR.png",
          width = 128,
          height = 16
        },
        {
          id = 77,
          image = "platform1.png",
          width = 128,
          height = 32
        },
        {
          id = 78,
          image = "platform2.png",
          width = 128,
          height = 32
        },
        {
          id = 79,
          image = "platform3.png",
          width = 128,
          height = 32
        },
        {
          id = 84,
          image = "elevator.png",
          width = 64,
          height = 96
        },
        {
          id = 85,
          image = "exit_signLEFT.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "EXITDOWN.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "EXITUP.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "platform2SMALL.png",
          width = 96,
          height = 32
        },
        {
          id = 91,
          image = "floorThickRim.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "floorThickRimx4.png",
          width = 128,
          height = 32
        },
        {
          id = 93,
          image = "floorThickRimx8.png",
          width = 256,
          height = 32
        },
        {
          id = 95,
          image = "pew.png",
          width = 40,
          height = 60
        },
        {
          id = 96,
          image = "flag1.png",
          width = 32,
          height = 64
        },
        {
          id = 97,
          image = "flag2.png",
          width = 32,
          height = 64
        },
        {
          id = 99,
          image = "spike5.png",
          width = 384,
          height = 32
        },
        {
          id = 102,
          image = "wall (1).png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "wall (1)x4.png",
          width = 128,
          height = 32
        },
        {
          id = 105,
          image = "wall (1)x12.png",
          width = 384,
          height = 32
        },
        {
          id = 107,
          image = "wall (1)x8.png",
          width = 256,
          height = 32
        },
        {
          id = 108,
          image = "wallDown (1)x4.png",
          width = 32,
          height = 128
        },
        {
          id = 109,
          image = "wallDown (1)x8.png",
          width = 32,
          height = 256
        },
        {
          id = 110,
          image = "wallDown (1)x12.png",
          width = 32,
          height = 384
        },
        {
          id = 111,
          image = "Steel Blue.png",
          width = 64,
          height = 64
        },
        {
          id = 113,
          image = "floorThickRimHalf.png",
          width = 32,
          height = 16
        },
        {
          id = 114,
          image = "floorThickRimHalfx2.png",
          width = 64,
          height = 16
        },
        {
          id = 115,
          image = "heart.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "feather.png",
          width = 96,
          height = 128
        },
        {
          id = 119,
          image = "Goose.png",
          width = 167,
          height = 199
        },
        {
          id = 120,
          image = "gooseHELMET.png",
          width = 160,
          height = 203
        },
        {
          id = 121,
          image = "gooseKING.png",
          width = 160,
          height = 213
        },
        {
          id = 122,
          image = "GooseKnife.png",
          width = 166,
          height = 199
        },
        {
          id = 123,
          image = "gun.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "hedge.png",
          width = 136,
          height = 66
        },
        {
          id = 125,
          image = "mush1.png",
          width = 98,
          height = 70
        },
        {
          id = 126,
          image = "mush2.png",
          width = 120,
          height = 100
        },
        {
          id = 127,
          image = "spike2half.png",
          width = 16,
          height = 32
        },
        {
          id = 128,
          image = "spike3half.png",
          width = 16,
          height = 32
        },
        {
          id = 129,
          image = "spikehalf.png",
          width = 16,
          height = 32
        },
        {
          id = 130,
          image = "buttonowo.png",
          width = 16,
          height = 16
        },
        {
          id = 131,
          image = "dangerZone.png",
          width = 128,
          height = 32
        },
        {
          id = 132,
          image = "exitSign.png",
          width = 32,
          height = 32
        },
        {
          id = 133,
          image = "bed.png",
          width = 128,
          height = 64
        },
        {
          id = 134,
          image = "help.png",
          width = 224,
          height = 96
        },
        {
          id = 135,
          image = "locker.png",
          width = 64,
          height = 96
        },
        {
          id = 136,
          image = "spike3andahalf.png",
          width = 112,
          height = 32
        },
        {
          id = 137,
          image = "actualBullet.png",
          width = 32,
          height = 32
        },
        {
          id = 138,
          image = "dangerZoneLonnnnnng.png",
          width = 640,
          height = 32
        },
        {
          id = 139,
          image = "asjadj.png",
          width = 128,
          height = 128
        },
        {
          id = 140,
          image = "asjadj_smaller.png",
          width = 96,
          height = 128
        },
        {
          id = 141,
          image = "Background2.png",
          width = 1033,
          height = 581
        },
        {
          id = 142,
          image = "CLIFF1.png",
          width = 96,
          height = 128
        },
        {
          id = 143,
          image = "CLIFF2.png",
          width = 128,
          height = 128
        },
        {
          id = 144,
          image = "dirt2.png",
          width = 32,
          height = 32
        },
        {
          id = 145,
          image = "floorPalace.png",
          width = 32,
          height = 32
        },
        {
          id = 146,
          image = "green.png",
          width = 32,
          height = 32
        },
        {
          id = 147,
          image = "green_top.png",
          width = 32,
          height = 32
        },
        {
          id = 148,
          image = "green2.png",
          width = 32,
          height = 32
        },
        {
          id = 149,
          image = "l_o_n_g.png",
          width = 59,
          height = 658
        },
        {
          id = 150,
          image = "oop.png",
          width = 352,
          height = 256
        },
        {
          id = 151,
          image = "oop2.png",
          width = 352,
          height = 256
        },
        {
          id = 152,
          image = "wallPALACE.png",
          width = 32,
          height = 32
        },
        {
          id = 153,
          image = "Window.png",
          width = 192,
          height = 416
        },
        {
          id = 154,
          image = "exitSurface.png",
          width = 64,
          height = 32
        },
        {
          id = 155,
          image = "platform3SMALL.png",
          width = 96,
          height = 32
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      id = 1,
      name = "Tile Layer 1",
      x = 0,
      y = 0,
      width = 60,
      height = 34,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "objectgroup",
      id = 5,
      name = "background",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 48,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 1088,
          width = 1919.85,
          height = 1088.82,
          rotation = 0,
          gid = 142,
          visible = true,
          properties = {}
        },
        {
          id = 49,
          name = "",
          type = "",
          shape = "rectangle",
          x = 1920,
          y = 416,
          width = 32,
          height = 640,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 50,
          name = "",
          type = "",
          shape = "rectangle",
          x = -32,
          y = 0,
          width = 32,
          height = 928,
          rotation = 0,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 2,
      name = "game",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 27,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 352,
          y = 928,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 28,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 448,
          y = 704,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 29,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 544,
          y = 864,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 34,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 192,
          y = 640,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 35,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1280,
          y = 640,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 37,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 480,
          y = 544,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 7,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = -64,
          y = 1184,
          width = 352,
          height = 256,
          rotation = 0,
          gid = 152,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 51,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1792,
          y = 512,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 144,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 52,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1664,
          y = 512,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 144,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 53,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1536,
          y = 512,
          width = 128,
          height = 128,
          rotation = 0,
          gid = 144,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 56,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 608,
          y = 544,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 57,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 896,
          y = 480,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 58,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1024,
          y = 480,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 59,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1440,
          y = 736,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 60,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1568,
          y = 736,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 61,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1696,
          y = 736,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 62,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 704,
          y = 800,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 63,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 832,
          y = 800,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 64,
          name = "",
          type = "ground",
          shape = "rectangle",
          x = 1152,
          y = 480,
          width = 129,
          height = 32,
          rotation = 0,
          gid = 78,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 3,
      name = "spikes",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 8,
          name = "spikes1",
          type = "spikes",
          shape = "rectangle",
          x = 288,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 15,
          name = "spikes2",
          type = "spikes",
          shape = "rectangle",
          x = 416,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 16,
          name = "spikes3",
          type = "spikes",
          shape = "rectangle",
          x = 544,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 17,
          name = "spikes4",
          type = "spikes",
          shape = "rectangle",
          x = 672,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 18,
          name = "spikes5",
          type = "spikes",
          shape = "rectangle",
          x = 800,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 19,
          name = "spikes6",
          type = "spikes",
          shape = "rectangle",
          x = 928,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 20,
          name = "spikes7",
          type = "spikes",
          shape = "rectangle",
          x = 1056,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 21,
          name = "spikes8",
          type = "spikes",
          shape = "rectangle",
          x = 1184,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 22,
          name = "spikes9",
          type = "spikes",
          shape = "rectangle",
          x = 1312,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 23,
          name = "spikes10",
          type = "spikes",
          shape = "rectangle",
          x = 1440,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 24,
          name = "spikes11",
          type = "spikes",
          shape = "rectangle",
          x = 1568,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 25,
          name = "spikes12",
          type = "spikes",
          shape = "rectangle",
          x = 1696,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 26,
          name = "spikes13",
          type = "spikes",
          shape = "rectangle",
          x = 1824,
          y = 1088,
          width = 128,
          height = 32,
          rotation = 0,
          gid = 68,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 4,
      name = "collectables",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 36,
          name = "heart",
          type = "collectables",
          shape = "rectangle",
          x = 224,
          y = 608,
          width = 64,
          height = 62.6667,
          rotation = 0,
          gid = 116,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 45,
          name = "feather",
          type = "collectables",
          shape = "rectangle",
          x = 1664,
          y = 704,
          width = 96,
          height = 128,
          rotation = 0,
          gid = 117,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 47,
          name = "gun",
          type = "collectables",
          shape = "rectangle",
          x = 1600,
          y = 384,
          width = 64.0909,
          height = 63.6667,
          rotation = -15,
          gid = 124,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    },
    {
      type = "objectgroup",
      id = 6,
      name = "exits",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 9,
          name = "elevator",
          type = "exits",
          shape = "rectangle",
          x = 0,
          y = 928,
          width = 64,
          height = 96,
          rotation = 0,
          gid = 85,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        },
        {
          id = 46,
          name = "exit",
          type = "exits",
          shape = "rectangle",
          x = 1920,
          y = 394,
          width = 64,
          height = 393.333,
          rotation = 0,
          gid = 109,
          visible = true,
          properties = {
            ["bodyType"] = "static"
          }
        }
      }
    }
  }
}
