local M = {}

function M.new(instance)

  if not instance then error("ERROR: Expected display object") end

local scene = composer.getScene( composer.getSceneName( "current" ) )

	if not instance.bodyType then
		physics.addBody( instance, "static", { isSensor = true } )
	end


	 function gotoDeathScreen()
	        composer.gotoScene("game over", { time=3000, effect="slideLeft" })
	    end

	--After loss of life
	function restoreChar()

	    character.isBodyActive = false
	    character.x = display.contentCenterX
	    character.y = ground.y - 150

	-- Fade in the character
	    transition.to( character, { alpha=1, time=100, onComplete = function()
	        character.isBodyActive = true
	            died = false
	        end
	    } )
	end


	--Collision with spikesStatic
function instance:collision( event )
	    if( event.phase == "began" ) then
	      local obj1 = event.object1
	      local obj2 = event.object2

	        if( ( obj1.myName == "character" and obj2.myName == "spikes" ) or ( obj1.myName == "spikes" and obj2.myName == "character" ) )then
	            if( died == false ) then
	              died = true
	                if( livesCount > 1 )then
	                  --Update lives
	                  livesCount = livesCount - 1
	                  livesText.text = "x" .. livesCount
	                  character.alpha = 0
	                  timer.performWithDelay( 100, restoreChar )
	                elseif( livesCount == 1 )then
										livesCount = livesCount - 1
	                  character.alpha = 0
	                  timer.performWithDelay( 1000, gotoDeathScreen )
	                end
	            end
	        end
	    end
	end

  instance:addEventListener( "collision" )
	return instance
end

return M
