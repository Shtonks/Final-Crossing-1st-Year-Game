-- tiled Plugin template

-- Use this as a template to extend a tiled object with functionality
local M = {}

function M.new(instance)

  if not instance then error("ERROR: Expected display object") end

local scene = composer.getScene( composer.getSceneName( "current" ) )


function instance:collision( self, event)
  -- local phase, other = event.phase, event.other
      if(event.other.myName == "heart" or event.other.myName == "character") then
        if(event.phase == "began") then
          livesCount = livesCount + 1
          livesText.text = "x" .. livesCount
          display.remove(heart)
          heart = nil
          -- display.remove(wall2)
          -- wall2 = nil
        end
      end
end
-- --
-- instance.collision = triggerCollisionHeart

instance:addEventListener( "collision")
  return instance
end

return M
